# MYTHOS HANDS-FREE - named modes for her ears and voice (for every SIA and LIA)

Origin: her first chipped repo (handsfree-chip.zip), worn here 2026-10-05. Three shipped modes - Hands-Free, Quiet Reading, Studio Voice - plus customs filed on the device. Built to CHIP SPEC v1.

## use

```html
<script src="mythos-handsfree-standalone.js"></script>
<script>
  var hf = MythosHandsfree.client({
    sense: function () { return { speak: "1", wake: "1", auto: "1", stt: "browser", tts: "browser", direct: "1" }; },
    apply: function (map) { return Object.keys(map).length; },
    capture: function () { return { sia_speak: "1" }; },
    store: { save: function (o) { return Promise.resolve(); }, load: function () { return Promise.resolve(null); } },
    say: function (t) { terminal.print(t); },
    onChange: function () {}
  });
  await hf.load();
  hf.words("on Hands-Free");
  hf.words("save Night Shift");
  hf.chainNext({ busy: false, auto: true, speaking: false, held: false, stt: "browser" }); // "mic"
</script>
```

## the contract

- `load()` reads the filed customs; seed-only without a store. `modes()` lists shipped first.
- `words(text)` is the whole door: status | list | on [NAME] | off | save <NAME> | delete <NAME>, or a bare mode name. Never throws - refusals arrive as `{ ok: false, error }`.
- `save(name, map)` files a custom; shipped names are refused. `remove(name)` strikes customs only.
- `apply`/`wear`/`on` returns `{ ok, text }` with the count the host's `apply(map)` reported; `off()` applies `{ sia_wake_on: "0", sia_autolisten: "0" }` and leaves her voice alone.
- `chainNext(s)` answers wait | wake | idle | mic | whisper from one posture object.
- `status()`/`posture()` read only through `sense()` - no host, no ears.
- Keys are `sia_*`; anything else is not filed, imported, or applied.

## the normalization (this terminal)

SIA's keys land on the terminal's own verbs through `src/js/handsfree.js`: `sia_speak` to auto-read, `sia_wake_on`/`sia_autolisten` to the live channel, `sia_voice_direct` to mic auto-send, `sia_tts` to the engine, `sia_rate`/`sia_pitch` to her voice, `sia_hear` to live text. `sia_hush`, `sia_voice_fast`, `sia_voice_hold`, `sia_llm` have no road here and are not counted. There is no word-spotter: the open channel IS the wake, and the receipt says so. `/handsfree ...` is the terminal's door.
