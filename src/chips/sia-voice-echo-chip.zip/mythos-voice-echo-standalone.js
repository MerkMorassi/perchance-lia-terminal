window.MythosVoiceEcho = (function () {
"use strict";
function client(opts) {
opts = opts || {};
var keep = (opts.keep == null || !(opts.keep > 0)) ? 4 : Math.floor(opts.keep);
var lines = [];
function say(n) { return String(n); }
function wordish(w) {
return say(w).toLowerCase().replace(/[^a-z0-9']/g, "");
}
function clean(s) {
var t = say(s == null ? "" : s);
t = t.replace(/\[\[[\s\S]*?\]\]/g, " ");
t = t.replace(/<\/?[a-zA-Z][^>]*>/g, " ");
t = t.replace(/[*_`#]+/g, " ");
t = t.replace(/\s*\n\s*/g, " ").replace(/\s{2,}/g, " ");
return t.trim();
}
function sameWord(a, b) {
if (!a || !b) return false;
if (a === b) return true;
if (a.length >= 4 && b.length >= 4 && a.slice(0, 4) === b.slice(0, 4)) return true;
return a.length >= 6 && b.length >= 6 && (a.indexOf(b) === 0 || b.indexOf(a) === 0);
}
function lcsWords(a, b) {
var m = a.length, n = b.length;
if (!m || !n) return 0;
var prev = [], cur = [], i, j;
for (j = 0; j <= n; j++) { prev[j] = 0; cur[j] = 0; }
for (i = 1; i <= m; i++) {
for (j = 1; j <= n; j++) {
cur[j] = sameWord(a[i - 1], b[j - 1]) ? prev[j - 1] + 1 : Math.max(prev[j], cur[j - 1]);
}
for (j = 0; j <= n; j++) { prev[j] = cur[j]; cur[j] = 0; }
}
return prev[n];
}
function remember(text) {
var prep = clean(text);
if (!prep) return { ok: false, error: "NOTHING TO REMEMBER, THE LINE IS EMPTY" };
var all = prep.toLowerCase().replace(/[^a-z0-9' ]+/g, " ").split(/\s+/).map(wordish).filter(Boolean);
var words = all.filter(function (w) { return w.length > 2; });
if (words.length < 3) return { ok: false, error: "TOO SHORT TO REMEMBER, THREE REAL WORDS AT LEAST" };
lines.push({ words: words, all: all, at: Date.now() });
while (lines.length > keep) lines.shift();
return { ok: true, kept: lines.length };
}
function check(text) {
var t = say(text == null ? "" : text);
if (!t.trim()) return { ok: false, error: "NOTHING TO CHECK, THE TRANSCRIPT IS EMPTY" };
if (!lines.length) return { ok: true, hers: false, memory: 0 };
var words = t.split(/\s+/).map(wordish).filter(function (w) { return w.length > 2; });
if (words.length < 3) return { ok: true, hers: false, short: true };
var runHit = false, bagHit = false, best = 0;
for (var l = 0; l < lines.length; l++) {
var pool = lines[l].words;
var run = lcsWords(words, pool);
if (run > best) best = run;
if (run >= 3 && (run / words.length) >= 0.5) runHit = true;
var hit = 0, i, j;
for (i = 0; i < words.length; i++) {
for (j = 0; j < pool.length; j++) { if (sameWord(pool[j], words[i])) { hit++; break; } }
}
if ((hit / words.length) >= 0.6) bagHit = true;
}
return { ok: true, hers: runHit || bagHit, run: best, memory: lines.length };
}
function strip(text) {
var raw = say(text == null ? "" : text).split(/\s+/).filter(Boolean);
if (!raw.length) return { ok: false, error: "NOTHING TO STRIP, THE TRANSCRIPT IS EMPTY" };
if (!lines.length) return { ok: true, text: raw.join(" "), cut: 0, hers: false };
var norm = raw.map(wordish);
var keepIt = [];
for (var k = 0; k < raw.length; k++) keepIt.push(true);
for (var l = 0; l < lines.length; l++) {
var pool = lines[l].all || lines[l].words;
var i = 0;
while (i < norm.length) {
if (!keepIt[i] || !norm[i]) { i++; continue; }
var best = 0, bestSub = 0;
for (var j = 0; j < pool.length; j++) {
var m = 0, sub = 0;
while (i + m < norm.length && j + m < pool.length && sameWord(pool[j + m], norm[i + m])) {
if (pool[j + m].length >= 4 && norm[i + m].length >= 4) sub++;
m++;
}
if (m > best) { best = m; bestSub = sub; }
}
if (best >= 3 && bestSub >= 2) { for (var d = 0; d < best; d++) keepIt[i + d] = false; i += best; }
else i++;
}
}
var kept = raw.filter(function (w, idx) { return keepIt[idx]; }).join(" ").replace(/\s+/g, " ").trim();
var cut = raw.length - kept.split(/\s+/).filter(Boolean).length;
return { ok: true, text: kept, cut: kept ? cut : raw.length, hers: cut > 0 };
}
function forget() {
lines = [];
return { ok: true, kept: 0 };
}
function state() {
return { ok: true, keep: keep, kept: lines.length };
}
return { remember: remember, check: check, strip: strip, forget: forget, state: state };
}
return { client: client };
})();
