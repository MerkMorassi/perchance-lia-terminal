# MYTHOS GALLERY - the catalogue and view engine over the vault (for every SIA and LIA)

Origin: ported 2026-10-05 from src/js/gallery.js (catalogue, kind/badge/note/title, filter/query/sort/page, selection, export). Built to CHIP SPEC v1.

## use

```html
<script src="mythos-gallery-standalone.js"></script>
<script>
  var gal = MythosGallery.client({
    vault: mediaVault(),   // { ensure?, list(), get(id), folderOf(rec), normFolder(p)?, allTags?, allFolders?, fileName?/artifactName?, isVox? }
    renderBook: book(),    // optional { labelOf(id) } - rows named on tiles and exports
    archive: turnArray,    // or readLog() -> [{ h, s, ts, img?, gen?, sight?, show? }]
    sightPending: () => unseen, // optional: ids still waiting for her eyes
    queueIds: (ids) => q(ids),  // optional doors the selection acts through
    saveId: (id) => dl(id),
    removeId: (id) => del(id)
  });
  await gal.refresh(); // rebuilds the catalogue, recomputes the view
  gal.setQuery("#night"); gal.setFilter("render"); gal.setPage(2);
  print(gal.describe());
</script>
```

Any source missing, its surface stays empty and says so; missing doors refuse LOUD. Nothing is silent.

## the contract

- `refresh()` — rebuilds the turn catalogue (first entry naming an id wins) and recomputes the whole filtered, sorted view. Views never filter: `rows()` is everything, `pageRows()` is the window.
- `setFilter` (all/render/sent/music/vox/clip/upscaled/unseen) / `setQuery` (folders, then `#tags`, then ANDed words — the same ladder as the book) / `setSort` (newest/oldest/biggest/az/turn) / `setPage` / `setPer` (24/60/120/240/all, remembered where a store is given). Unknown values refused, view untouched.
- `toggleTag` / `toggleFolder` — chips that mean exactly what typing means. `pageOfId` / `reveal` — the page holding one record, 0 when the view doesn't.
- `toggleSel` / `selectAll` / `clearSel` / `selected` + `queueSelected` / `saveSelected` / `deleteSelected` — the selection and the three doors it walks through.
- `kindOf` / `badgeFor` / `noteFor` / `titleFor` — what a record is, its one line, its turn story, its full tooltip. `exportCatalogue()` — `{ json, text }` of the whole view. `describe()` / `state()` / `find(q)` report.
- Seams: `vault`, `renderBook`, `archive` / `readLog`, `sightPending`, `queueIds`, `saveId`, `removeId`, `download`, `viewStore`, `stamp`, `perDefault`.

## deliberately left out

- The tiles, the pager chrome, the lightbox, the thumbnails — host painting; the chip is the engine they draw.
- The file import (it leans on canvas) and the DOM download anchors — `download` is the seam.
- The `/gallery` verbs — host wiring; the chip answers what they ask.

## honesty note

A page is a drawing decision, never a filter — counts, exports and walks always see the whole view, and anything that claims otherwise is lying about the vault.
