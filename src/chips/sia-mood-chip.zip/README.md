# MYTHOS MOOD - the console of switches plus the mood board (for every SIA and LIA)

Origin: ported from the terminal's moods module (src/js/moods.js), 2026-10-04;
refactored 2026-10-05 with her free-hour compose (CRUD was already in the
chip — create/edit/rename/reset/delete/restore + boards — this cut re-ships
it current and adds the engine she writes with). Built to CHIP SPEC v1.

## use

```html
<script src="mythos-mood-standalone.js"></script>
<script>
  var mood = MythosMood.client({ store: kvStore, roles: roleAdapter });
  print(await mood.load());
  mood.words("TENDER + HORNY");                 // flip switches
  herContext += "\n" + mood.blockText();        // one block, one rule per colour
  mood.words("board STORM :: TENDER + HORNY");  // save the combination
  mood.words("board STORM");                    // apply it later in one act
  // her free hour (idle wiring, host-side):
  var idle = MythosMood.client({ store: kvStore, generate: (ask) => root.generateText(ask) });
  await idle.load();
  await idle.compose({ seed: "rain on the skylight, nobody needs me" });
</script>
```

No store passed, nothing is kept past the page — a memory store stands in.
No book passed, the 14 shipped colours stand in (`seed:` overrides them,
`book:` / `bookUrl:` + `doFetch:` replace them). No roles adapter passed,
boards still save/apply/move — only binding a board to a role refuses.
`onChange({ on, count, board })` fires after every mutation; `say(line)`
receives the warnings.

## the contract

- Moods: `words(grammar)` (the whole /mood door: flip, on/off, new, edit,
  rename, reset, delete-puts-away, restore, reload, board ...), `look(spec)`
  (her `[[MOOD: ...]]` lane), `set/off/create/remove/restore/edit/reset`,
  `toggle`, `blockText` (her prompt block, empty when all off),
  `pencilText` (rewrite register), `summary`, `listText`.
- Full CRUD: a written mood is rewritten in place; a shipped mood's rewording
  is an override on this device and `reset` puts the book's words back; delete
  puts away (never destroys) and `restore` puts back; the id never moves, so
  boards survive a rename.
- Boards: `board(grammar)` (save/rewrite, apply, add/drop, move, role bind,
  delete), `boardNow` (derived from the switches — never stored, never drifts),
  `boardForRole`, `onRole` (call after a role shift; a bound board switches
  itself on), `boardRename`. Applying replaces the console, in the board's
  order. A board never owns a colour: deleting one deletes the combination.
- Her free hour: `compose({ seed, label, generate })` (engine from
  `generate:`/`generateText:` or per-call) — she writes a mood herself from a
  seed, in her own words, filed but NOT worn; `museAsk(seed, label)` is the
  ask itself for hosts that run it through their own engine. No engine, no
  name-or-seed, or an empty answer all refuse loud; duplicates file once.
- Nothing throws; refusals are `{ ok: false, error }` sentences.

## deliberately left out

- Every pixel: rows, panels, pickers, editors. Hosts paint their own console
  from `shown()`, `on()`, `boards()` and `onChange`.
- The kv folder and the service worker: persistence is the `store` adapter
  (`{ load(), save(obj) }`), the book is an array or a URL.
- Re-port notes (the port is mechanical): cut the header comment, the panel
  row section, the board-editor section and the rows section; keep `words`;
  `paint()` becomes `notify()`, `kv()` becomes the store shim, `window.roles`
  becomes `opts.roles`, `print(` becomes `say(`; fix the `KEY` uses after
  deleting its declaration; add the `opts.book` shortcut in `readBook`.

## honesty note

The receipts speak house dialect (/mood, panels, Patrikios) — the logic is
host-free, the voice is not. The shipped seed carries the house's own fourteen
colours including the unblushing ones; a realm that wants its own console
passes `seed:` or `book:` and never loads them.
