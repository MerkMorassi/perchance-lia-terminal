// SPACE PROOF CASES - fix order item 4 (MYTHOS-LOREPACK-FACTORY-MVP).
//
// SP-01: mixed-dimension input refused at export (nothing leaves the factory).
// SP-02: quota failure throws LOUD (does NOT emit 768-D fallback vectors).
// SP-03: clean 50-doc run exports exactly one space.
//
// No node dependencies (no fs/path/process): runs inside src/acceptance-test.ts
// AND headless against InMemoryLorepackStore. Wire shape unchanged.

import type { TripletEdge, VectorRecord } from './types.js';

export interface SpaceProofStore {
  nukeStore(): Promise<void>;
  addRecordsAtomic(vectors: VectorRecord[], edges: TripletEdge[]): Promise<void>;
  getVectorsByAgent(agentId: string): Promise<VectorRecord[]>;
}

export interface SpaceProofFactory {
  ingestBatches(
    batches: Array<{ text: string; source: string }>,
    options: { agentId: string; batchSize?: number }
  ): Promise<{ ingested: number; failed: Array<{ text: string; reason: string }> }>;
  exportLorepack(
    agentId: string,
    options?: { gzip?: boolean }
  ): Promise<{ blob: Blob; count: number; filename: string }>;
  yieldExportBatches(agentId: string, batchSize?: number): AsyncGenerator<object[]>;
}

export interface SpaceProofProvider {
  setApiKeys?(keys: string[]): void;
  getEmbeddingsBatch(texts: string[]): Promise<number[][]>;
}

export interface SpaceProofDeps {
  store: SpaceProofStore;
  factory: SpaceProofFactory;
  provider: SpaceProofProvider;
  getFetch(): any;
  setFetch(fn: any): void;
}

export interface SpaceProofResult {
  passed: string[];
  failed: Array<{ id: string; error: string }>;
}

function mock768(url: string, init?: any): Promise<any> {
  const u = String(url);
  if (u.includes('batchEmbedContents')) {
    let n = 1;
    try {
      n = JSON.parse(init?.body || '{}').requests?.length || 1;
    } catch {
      n = 1;
    }
    return Promise.resolve({
      ok: true,
      status: 200,
      json: async () => ({ embeddings: Array(n).fill({ values: Array(768).fill(0.123) }) }),
    });
  }
  if (u.includes('embedContent') || u.includes('/api/lorepack/embed')) {
    const direct = u.includes('embedContent');
    return Promise.resolve({
      ok: true,
      status: 200,
      json: async () =>
        direct ? { embedding: { values: Array(768).fill(0.123) } } : { embedding: Array(768).fill(0.123) },
    });
  }
  return Promise.reject(new Error('Unhandled mock fetch for: ' + u));
}

function mockQuota(url: string): Promise<any> {
  const u = String(url);
  if (u.includes('embedContent') || u.includes('batchEmbedContents') || u.includes('/api/lorepack/embed')) {
    return Promise.resolve({
      ok: false,
      status: 429,
      json: async () => ({ error: { message: 'Quota exceeded (mock 429)', code: 429 } }),
    });
  }
  return Promise.reject(new Error('Unhandled mock fetch for: ' + u));
}

function honVec(id: string, agent: string, dim: number, fill: number): VectorRecord {
  return {
    id,
    agentId: agent,
    text: 'honest record ' + id,
    vector: Array(dim).fill(fill),
    source: 'SPACE_PROOF_SRC',
    timestamp: Date.now(),
    metadata: { embeddingModel: 'gemini-embedding-2', embeddingDimension: dim },
  };
}

export async function runSpaceProof(
  deps: SpaceProofDeps,
  onLog: (line: string) => void = () => {}
): Promise<SpaceProofResult> {
  const passed: string[] = [];
  const failed: Array<{ id: string; error: string }> = [];
  const { store, factory, provider } = deps;

  // --- SP-01: mixed-dimension input refused at export ---
  try {
    await store.nukeStore();
    await store.addRecordsAtomic(
      [honVec('sp_mix_768', 'AGENT_SPACE_MIX', 768, 0.5), honVec('sp_mix_3072', 'AGENT_SPACE_MIX', 3072, 0.5)],
      []
    );
    let threw = '';
    try {
      await factory.exportLorepack('AGENT_SPACE_MIX', { gzip: false });
    } catch (e: any) {
      threw = String(e?.message || e);
    }
    if (!threw) throw new Error('export wrote a mixed-dimension pack without refusing');
    if (!/mixed|dimension|space/i.test(threw)) throw new Error('refusal reason names no space violation: ' + threw);

    // Lying stamp: d.embeddingDimension disagrees with the real length.
    const liar = honVec('sp_liar', 'AGENT_SPACE_LIAR', 768, 0.5);
    (liar.metadata as any).embeddingDimension = 100;
    await store.addRecordsAtomic([liar], []);
    let threw2 = '';
    try {
      await factory.exportLorepack('AGENT_SPACE_LIAR', { gzip: false });
    } catch (e: any) {
      threw2 = String(e?.message || e);
    }
    if (!threw2) throw new Error('export wrote a stamp-lying pack without refusing');
    if (!/mismatch/i.test(threw2)) throw new Error('refusal reason names no stamp mismatch: ' + threw2);

    // Refusal wrote nothing out AND deleted nothing.
    const survivors = await store.getVectorsByAgent('AGENT_SPACE_MIX');
    if (survivors.length !== 2) throw new Error('refused export disturbed the vault: ' + survivors.length);
    passed.push('SP-01');
    onLog('SP-01 mixed-dimension + lying-stamp export refused, vault intact :: ' + threw.slice(0, 90));
  } catch (e: any) {
    failed.push({ id: 'SP-01', error: String(e?.message || e) });
  }

  // --- SP-02: quota failure throws, emits no 768-D vectors ---
  const prevFetch = deps.getFetch();
  try {
    await store.nukeStore();
    if (provider.setApiKeys) provider.setApiKeys(['SPACE_PROOF_QUOTA_KEY']);
    deps.setFetch(mockQuota);

    let threw = '';
    try {
      await provider.getEmbeddingsBatch(['quota probe one', 'quota probe two']);
    } catch (e: any) {
      threw = String(e?.message || e);
    }
    if (!threw) throw new Error('provider returned vectors through a quota failure (silent fallback alive)');
    if (!threw.includes('NOTHING WAS EMBEDDED')) throw new Error('failure was not loud: ' + threw);

    let ingestThrew = '';
    try {
      await factory.ingestBatches(
        [
          { text: 'quota doc one', source: 'SPACE_PROOF_QUOTA' },
          { text: 'quota doc two', source: 'SPACE_PROOF_QUOTA' },
        ],
        { agentId: 'AGENT_SPACE_QUOTA' }
      );
    } catch (e: any) {
      ingestThrew = String(e?.message || e);
    }
    if (!ingestThrew) throw new Error('ingest swallowed a total quota failure');
    const leftovers = await store.getVectorsByAgent('AGENT_SPACE_QUOTA');
    if (leftovers.length !== 0)
      throw new Error('quota run left ' + leftovers.length + ' vectors (fallback geometry?) in the vault');
    passed.push('SP-02');
    onLog('SP-02 quota throws loud, 0 vectors stored :: ' + ingestThrew.slice(0, 90));
  } catch (e: any) {
    failed.push({ id: 'SP-02', error: String(e?.message || e) });
  } finally {
    deps.setFetch(prevFetch);
    if (provider.setApiKeys) provider.setApiKeys([]);
  }

  // --- SP-03: clean 50-doc run exports one space ---
  try {
    await store.nukeStore();
    deps.setFetch(mock768);
    const docs = Array.from({ length: 50 }, (_, i) => ({
      text: `clean space doc ${i}: Barbelo holds the vault and the vault holds.`,
      source: 'SPACE_PROOF_CLEAN',
    }));
    const res = await factory.ingestBatches(docs, { agentId: 'AGENT_SPACE_CLEAN', batchSize: 25 });
    if (res.ingested !== 50) throw new Error(`ingested ${res.ingested}/50 clean docs`);
    if (res.failed.length) throw new Error(`clean run reported failures: ${res.failed[0].reason}`);

    const lines: any[] = [];
    for await (const batch of factory.yieldExportBatches('AGENT_SPACE_CLEAN', 25)) lines.push(...batch);
    const vecs = lines.filter((l) => l.type !== 'edge');
    if (vecs.length !== 50) throw new Error(`exported ${vecs.length}/50 vectors`);
    const dims = new Set(vecs.map((v) => (v.vec || []).length));
    const models = new Set(vecs.map((v) => (v.d as any)?.embeddingModel || 'unknown'));
    if (dims.size !== 1 || !dims.has(768)) throw new Error('exported dims: ' + Array.from(dims).join(','));
    if (models.size !== 1 || !models.has('gemini-embedding-2'))
      throw new Error('exported models: ' + Array.from(models).join(','));

    const dl = await factory.exportLorepack('AGENT_SPACE_CLEAN', { gzip: true });
    if (!dl.blob || dl.blob.size === 0) throw new Error('export produced an empty blob');
    if (!dl.filename.endsWith('.lorepack.gz')) throw new Error('export filename broke: ' + dl.filename);
    passed.push('SP-03');
    onLog(`SP-03 clean 50-doc run :: one space (768-D, gemini-embedding-2) :: blob ${dl.blob.size}B ${dl.filename}`);
  } catch (e: any) {
    failed.push({ id: 'SP-03', error: String(e?.message || e) });
  } finally {
    deps.setFetch(prevFetch);
  }

  await store.nukeStore();
  return { passed, failed };
}
